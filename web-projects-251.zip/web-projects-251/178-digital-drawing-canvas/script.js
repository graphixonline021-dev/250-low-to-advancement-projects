const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "draw", "k": "178-digital-drawing-canvas"};

const cv=$('#cv'),x=cv.getContext('2d'),S=CFG.sym||1;let dn=0,l;x.lineCap='round';x.fillStyle='#fff';x.fillRect(0,0,600,400);
const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height]};
cv.onpointerdown=e=>{dn=1;l=pt(e)};onpointerup=()=>dn=0;
cv.onpointermove=e=>{if(!dn)return;const p=pt(e);x.strokeStyle=$('#c').value;x.lineWidth=$('#z').value;for(let i=0;i<S;i++){x.save();x.translate(300,200);x.rotate(i*6.2832/S);x.translate(-300,-200);x.beginPath();x.moveTo(...l);x.lineTo(...p);x.stroke();x.restore()}l=p};
$('#cl').onclick=()=>{x.fillStyle='#fff';x.fillRect(0,0,600,400)};$('#sv').onclick=()=>{const a=document.createElement('a');a.href=cv.toDataURL();a.download='drawing.png';a.click()};