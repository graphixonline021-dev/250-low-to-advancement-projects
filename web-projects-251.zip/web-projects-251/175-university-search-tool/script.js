const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://universities.hipolabs.com/search?name='+encodeURIComponent(q));return d.slice(0,15).map(u=>`<div class=card style=\"margin:.4rem 0\"><b>${esc(u.name)}</b> — ${esc(u.country)}<br><a target=_blank href=\"${esc((u.web_pages||[])[0]||'#')}\">${esc((u.web_pages||[])[0]||'')}</a></div>`).join('')||'None found'", "q": "karachi", "ph": "University name", "k": "175-university-search-tool"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();