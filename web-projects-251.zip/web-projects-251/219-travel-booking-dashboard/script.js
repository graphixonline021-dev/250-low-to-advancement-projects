const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"m": ["Bookings", "Destinations", "Revenue", "Cancellations"], "cols": ["Traveler", "Trip", "Price", "Status"], "k": "219-travel-booking-dashboard"};

const C=CFG,R=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
function gen(){$('#mt').innerHTML=C.m.map(l=>`<div class=card>${l}<div class=big>${R(100,9999).toLocaleString()}</div><small style="color:${R(0,1)?'#2a2':'#d33'}">${R(0,1)?'▲':'▼'} ${R(1,25)}%</small></div>`).join('');
const x=$('#cv').getContext('2d'),D=[...Array(12)].map(()=>R(20,100)),W=700,H=260;x.fillStyle='#fff';x.fillRect(0,0,W,H);x.strokeStyle=x.fillStyle='#4a7cff';
if(C.chart=='line'){x.beginPath();D.forEach((v,i)=>x[i?'lineTo':'moveTo'](50+i*55,H-20-v*2.2));x.lineWidth=3;x.stroke()}else D.forEach((v,i)=>x.fillRect(30+i*55,H-20-v*2.2,38,v*2.2));
x.fillStyle='#666';'JFMAMJJASOND'.split('').forEach((l,i)=>x.fillText(l,(C.chart=='line'?50:45)+i*55,H-4));
const N=['Alex','Sam','Priya','Omar','Li','Maria','Noah'],S=['Active','Pending','Done','Delayed'];
$('#tb').innerHTML='<tr>'+C.cols.map(c=>`<th>${c}</th>`).join('')+'</tr>'+[...Array(6)].map(()=>'<tr>'+C.cols.map((c,i)=>`<td>${i==0?N[R(0,6)]:i==C.cols.length-1?S[R(0,3)]:R(10,999)}</td>`).join('')+'</tr>').join('')}
gen();if(C.live)setInterval(gen,2500);