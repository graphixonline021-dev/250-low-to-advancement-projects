const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "return '<pre>'+esc(t).replace(/(\\/\\/.*)/g,'<i class=cm>$1</i>').replace(/\\b(const|let|var|function|return|if|else|for|while|class|new|import|from)\\b/g,'<b class=kw>$1</b>').replace(/(&#39;.*?&#39;|&quot;.*?&quot;)/g,'<span class=st>$1</span>')+'</pre>'", "init": "// sample\nconst greet = (n) => {\n  return 'Hello ' + n;\n};", "rows": 8, "k": "241-syntax-highlighting-demo"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();