const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "memory", "e": ["😀", "😎", "🤖", "👻", "🐱", "🦊", "🌈", "⭐"], "k": "100-emoji-matching-game"};
const E=CFG.e;let c=[...E,...E].sort(()=>Math.random()-.5),o=[],f=[],mv=0,lock=0;const G=$('#game');G.className='grid4';
function d(){G.innerHTML=c.map((e,i)=>`<button class=cell onclick=fl(${i})>${o.includes(i)||f.includes(i)?e:'❓'}</button>`).join('')}
function fl(i){if(lock||o.includes(i)||f.includes(i))return;o.push(i);d();if(o.length==2){mv++;lock=1;setTimeout(()=>{if(c[o[0]]==c[o[1]])f.push(...o);o=[];lock=0;d();$('#out').textContent=`Moves: ${mv}`+(f.length==c.length?' — You won! 🎉':'')},600)}}d();