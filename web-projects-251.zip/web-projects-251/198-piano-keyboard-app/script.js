const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "audio", "m": "piano", "k": "198-piano-keyboard-app"};

const AC=new(window.AudioContext||window.webkitAudioContext)(),AN=AC.createAnalyser(),m=CFG.m;AN.connect(AC.destination);
function tone(f,d,t){const o=AC.createOscillator(),g=AC.createGain();o.type=t;o.frequency.value=f;g.gain.setValueAtTime(.3,AC.currentTime);g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+d);o.connect(g);g.connect(AN);o.start();o.stop(AC.currentTime+d)}
const dr=m=='drum',KK=dr?'12345678'.split(''):'awsedftgyhujk'.split(''),N=KK.length;
const pl=i=>{AC.resume();tone(dr?[60,120,200,300,440,800,1200,2000][i]:261.63*2**(i/12),dr?.15:.5,dr?['sine','triangle','sawtooth','square'][i%4]:'triangle');const el=document.querySelectorAll('.key')[i];el.classList.add('on');setTimeout(()=>el.classList.remove('on'),150)};
$('#keys').innerHTML=KK.map((k,i)=>`<button class="key big" onclick=pl(${i})>${k.toUpperCase()}</button>`).join('');
addEventListener('keydown',e=>{const i=KK.indexOf(e.key);if(i>=0&&!e.repeat)pl(i)});
if(m=='viz'){const b=document.createElement('button');b.textContent='▶ Play melody';b.onclick=()=>[0,4,7,12,7,4,0,5,9,12].forEach((n,k)=>setTimeout(()=>pl(n),k*300));$('#keys').after(b)}
const x=$('#cv').getContext('2d'),D=new Uint8Array(AN.frequencyBinCount);(function a(){AN.getByteFrequencyData(D);x.fillStyle='#111';x.fillRect(0,0,700,120);for(let i=0;i<64;i++){x.fillStyle=`hsl(${i*5},80%,55%)`;const h=D[i]/2.2;x.fillRect(i*11,120-h,9,h)}requestAnimationFrame(a)})();