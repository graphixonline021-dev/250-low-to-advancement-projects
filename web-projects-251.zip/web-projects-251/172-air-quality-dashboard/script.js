const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const g=(await j(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=1`)).results?.[0];if(!g)return'City not found';const a=(await j(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${g.latitude}&longitude=${g.longitude}&current=us_aqi,pm2_5,pm10`)).current;return `<h3>${esc(g.name)}</h3><div class=big>AQI ${a.us_aqi}</div>PM2.5: ${a.pm2_5} µg/m³ · PM10: ${a.pm10} µg/m³`", "q": "Karachi", "ph": "City", "k": "172-air-quality-dashboard"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();