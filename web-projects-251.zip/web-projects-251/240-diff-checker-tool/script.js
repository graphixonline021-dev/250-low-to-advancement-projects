const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const a=t.split('\\n'),b=u.split('\\n');let r='';for(let i=0;i<Math.max(a.length,b.length);i++){if(a[i]===b[i])r+=esc(a[i]??'')+'\\n';else{if(a[i]!==undefined)r+='<del>- '+esc(a[i])+'</del>\\n';if(b[i]!==undefined)r+='<ins>+ '+esc(b[i])+'</ins>\\n'}}return '<pre>'+r+'</pre>'", "ph": "Original text", "ph2": "Changed text", "rows": 5, "init": "line one\nline two\nline three", "k": "240-diff-checker-tool"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();