# 251 Web Projects

Open `index.html` in a browser to browse everything. Each project folder has `index.html`, `style.css` and `script.js` (no build step, no dependencies).

Notes:
- Many projects share the same underlying engine (to-do style lists, calculators, forms, shops, dashboards) with different configs — a good base to extend.
- Section 7 (API projects) and a few others (QR code, map) need an internet connection and use free public APIs that may be rate-limited.
- Dashboards use randomly generated sample data. Payment, password-vault, slot-machine and card projects are UI demos only.
