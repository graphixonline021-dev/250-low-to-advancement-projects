const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"side": 1, "k": "210-messaging-app-prototype"};

const C=CFG,names=C.side?['Ayesha','Bilal','Team Chat']:['Assistant'];let cur=0,H=names.map(()=>[]);const rp=['Sounds good!','Tell me more.','👍','Got it, thanks!','Let me check and get back to you.'];
function d(){$('#side').innerHTML=C.side?names.map((n,i)=>`<button class="${i==cur?'on':''}" onclick="cur=${i};d()">${n}</button>`).join(''):'';$('#msgs').innerHTML=H[cur].map(m=>`<div class="m ${m[0]}">${esc(m[1])}</div>`).join('');$('#msgs').scrollTop=1e9}
function send(){const v=$('#in').value.trim();if(!v)return;const c=cur;H[c].push(['me',v]);$('#in').value='';d();setTimeout(()=>{H[c].push(['bot',rp[Math.floor(Math.random()*rp.length)]]);d()},700)}
$('#send').onclick=send;$('#in').onkeydown=e=>e.key=='Enter'&&send();d();