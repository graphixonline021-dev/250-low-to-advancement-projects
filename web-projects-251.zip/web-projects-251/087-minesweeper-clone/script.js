const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "mines", "k": "087-minesweeper-clone"};
const N=9;let m=new Set(),op=new Set(),fg=new Set(),over=0;while(m.size<10)m.add(Math.floor(Math.random()*81));
const nb=i=>{const r=[],y=Math.floor(i/N),x=i%N;for(let a=-1;a<2;a++)for(let b=-1;b<2;b++){const Y=y+a,X=x+b;if((a||b)&&Y>=0&&Y<N&&X>=0&&X<N)r.push(Y*N+X)}return r},cnt=i=>nb(i).filter(k=>m.has(k)).length;
function rv(i){if(op.has(i)||fg.has(i))return;op.add(i);if(!m.has(i)&&!cnt(i))nb(i).forEach(rv)}
function d(){$('#game').className='grid9';$('#game').innerHTML=[...Array(81)].map((_,i)=>`<button class="cell sm" onclick=cl(${i}) oncontextmenu="fgl(${i});return false">${op.has(i)?(m.has(i)?'💣':cnt(i)||''):fg.has(i)?'🚩':''}</button>`).join('')}
function cl(i){if(over)return;if(m.has(i)){over=1;m.forEach(k=>op.add(k));$('#out').textContent='💥 Boom! Game over'}else{rv(i);if(op.size==71)$('#out').textContent='You won! 🎉'}d()}
function fgl(i){fg.has(i)?fg.delete(i):fg.add(i);d()}$('#out').textContent='Right-click to flag a mine';d();