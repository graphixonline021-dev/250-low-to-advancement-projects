const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "g2048", "k": "085-2048-number-puzzle"};
let g=Array(16).fill(0);const L=(d,i,j)=>[i*4+j,i*4+3-j,j*4+i,(3-j)*4+i][d];
function add(){const e=g.map((v,i)=>v?-1:i).filter(i=>i>=0);if(e.length)g[e[Math.floor(Math.random()*e.length)]]=Math.random()<.9?2:4}
function slide(r){r=r.filter(v=>v);for(let i=0;i<r.length-1;i++)if(r[i]==r[i+1]){r[i]*=2;r.splice(i+1,1)}while(r.length<4)r.push(0);return r}
function mv(d){const o=g.join();for(let i=0;i<4;i++){const ix=[0,1,2,3].map(j=>L(d,i,j)),r=slide(ix.map(k=>g[k]));ix.forEach((k,j)=>g[k]=r[j])}if(g.join()!=o)add();draw()}
function draw(){$('#game').innerHTML=g.map(v=>`<div class=cell style="background:hsl(${40+Math.log2(v||1)*25},70%,${v?60:85}%);color:#222">${v||''}</div>`).join('');$('#out').textContent='Max tile: '+Math.max(...g)+' (arrow keys)'}
$('#game').className='grid4';addEventListener('keydown',e=>{const d=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].indexOf(e.key);if(d>=0){e.preventDefault();mv(d)}});add();add();draw();