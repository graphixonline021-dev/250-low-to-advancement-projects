const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "a11y", "k": "126-accessible-form-components"};
$('#dsc').onclick=()=>{const o=$('#pn').hidden;$('#pn').hidden=!o;$('#dsc').setAttribute('aria-expanded',o);$('#lv').textContent=o?'Details shown':'Details hidden'}