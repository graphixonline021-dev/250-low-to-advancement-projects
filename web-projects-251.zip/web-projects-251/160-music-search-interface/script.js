const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://itunes.apple.com/search?media=music&limit=10&term='+encodeURIComponent(q));return d.results.map(m=>`<div class=card style=\"margin:.4rem 0\"><b>${esc(m.trackName)}</b> — ${esc(m.artistName)}<br><audio controls src=\"${esc(m.previewUrl)}\" style=\"width:100%\"></audio></div>`).join('')", "q": "coldplay", "ph": "Song or artist", "k": "160-music-search-interface"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();