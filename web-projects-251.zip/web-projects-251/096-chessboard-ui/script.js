const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "board", "k2": "chess", "k": "096-chessboard-ui"};
const bk='♜♞♝♛♚♝♞♜',wh='♖♘♗♕♔♗♘♖';let b=Array(64).fill('');
if(CFG.k2=='chess'){for(let i=0;i<8;i++){b[i]=bk[i];b[8+i]='♟';b[48+i]='♙';b[56+i]=wh[i]}}else{for(let i=0;i<64;i++){const r=Math.floor(i/8),c=i%8;if((r+c)%2){if(r<3)b[i]='⚫';if(r>4)b[i]='⚪'}}}
let sel=-1;$('#game').className='grid8';$('#out').textContent='Click a piece, then click a square to move it (rules are not enforced).';
function d(){$('#game').innerHTML=b.map((p,i)=>`<button class="sq" style="background:${(Math.floor(i/8)+i)%2?'#b58863':'#f0d9b5'};color:#000;${i==sel?'outline:3px solid #36f':''}" onclick=pk(${i})>${p}</button>`).join('')}
function pk(i){if(sel<0){if(b[i])sel=i}else{const s=sel;if(i!=s){b[i]=b[s];b[s]=''}sel=-1}d()}d();