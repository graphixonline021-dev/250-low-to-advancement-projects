const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "patt", "p": "pattern", "k": "183-pattern-generator-studio"};

const cv=$('#cv'),x=cv.getContext('2d'),rnd=Math.random;
function gn(){const h=rnd()*360;if(CFG.p=='wall'){const gr=x.createLinearGradient(0,0,700,400);gr.addColorStop(0,`hsl(${h},80%,55%)`);gr.addColorStop(1,`hsl(${h+80},80%,45%)`);x.fillStyle=gr;x.fillRect(0,0,700,400)}else{x.fillStyle=`hsl(${h},40%,15%)`;x.fillRect(0,0,700,400);const s=40;for(let i=0;i<18;i++)for(let j=0;j<10;j++){x.fillStyle=`hsl(${h+rnd()*90},70%,60%)`;const k=Math.floor(rnd()*3);x.beginPath();if(k==0)x.arc(i*s+20,j*s+20,15,0,7);else if(k==1)x.rect(i*s+5,j*s+5,30,30);else{x.moveTo(i*s+20,j*s+4);x.lineTo(i*s+36,j*s+36);x.lineTo(i*s+4,j*s+36)}x.fill()}}}
$('#g').onclick=gn;$('#sv').onclick=()=>{const a=document.createElement('a');a.href=cv.toDataURL();a.download='art.png';a.click()};gn();