const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://date.nager.at/api/v3/PublicHolidays/2026/'+encodeURIComponent(q.toUpperCase()));return '<table>'+d.map(h=>`<tr><td>${h.date}</td><td>${esc(h.name)}</td></tr>`).join('')+'</table>'", "q": "US", "ph": "Country code (US, GB, PK…)", "k": "168-public-holiday-calendar"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();