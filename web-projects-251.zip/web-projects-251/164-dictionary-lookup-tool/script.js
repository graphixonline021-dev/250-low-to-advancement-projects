const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://api.dictionaryapi.dev/api/v2/entries/en/'+encodeURIComponent(q));return d.map(e=>`<h3>${esc(e.word)} <small>${esc(e.phonetic||'')}</small></h3>`+e.meanings.map(m=>`<p><i>${m.partOfSpeech}</i>: ${esc(m.definitions[0].definition)}</p>`).join('')).join('')", "q": "serendipity", "ph": "English word", "k": "164-dictionary-lookup-tool"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();