const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"f": [["i", "Income", 3000], ["r", "Rent", 1000], ["f", "Food", 400], ["t", "Transport", 150], ["o", "Other", 300]], "js": "const s=v.r+v.f+v.t+v.o,l=v.i-s;return `Spent <b>$${s}</b> · Left <b style=\\\"color:${l<0?'#d33':'#2a2'}\\\">$${l}</b> (${v.i?Math.round(l/v.i*100):0}% saved)`", "k": "065-monthly-budget-planner"};

$('#form').innerHTML=CFG.f.map(([i,l,d,o])=>`<label>${l}${Array.isArray(o)?`<select id=${i}>${o.map(x=>`<option>${x}</option>`).join('')}</select>`:`<input id=${i} type=${o||'number'} value="${d}">`}</label>`).join('');
const run=()=>{const v={};CFG.f.forEach(([i,,,o])=>{const e=$('#'+i);v[i]=o?e.value:+e.value});try{$('#out').innerHTML=new Function('v',CFG.js)(v)}catch(e){$('#out').textContent='Check your inputs'}};
$('#form').oninput=run;run();