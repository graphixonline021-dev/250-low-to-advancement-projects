const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "ttt", "k": "077-tic-tac-toe-game"};
let b=Array(9).fill(''),t='X',over=0;const G=$('#game');G.className='grid3';
function d(){G.innerHTML=b.map((v,i)=>`<button class=cell onclick=mv(${i})>${v}</button>`).join('')}
function mv(i){if(b[i]||over)return;b[i]=t;const w=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].find(l=>l.every(k=>b[k]==t));over=w||b.every(x=>x);$('#out').textContent=w?t+' wins!':over?'Draw':'';t=t=='X'?'O':'X';d()}d();