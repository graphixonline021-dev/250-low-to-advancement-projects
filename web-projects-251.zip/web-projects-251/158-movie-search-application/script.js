const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://itunes.apple.com/search?media=movie&limit=12&term='+encodeURIComponent(q));return '<div class=cards>'+d.results.map(m=>`<div class=card><img src=\"${esc(m.artworkUrl100)}\" width=100><br><b>${esc(m.trackName)}</b><br><small>${esc(m.primaryGenreName)} · ${(m.releaseDate||'').slice(0,4)}</small></div>`).join('')+'</div>'", "q": "batman", "ph": "Movie title", "k": "158-movie-search-application"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();