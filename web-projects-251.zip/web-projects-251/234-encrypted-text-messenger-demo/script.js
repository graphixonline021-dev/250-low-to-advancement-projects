const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const k=u||'key',x=s=>[...s].map((c,i)=>String.fromCharCode(c.charCodeAt(0)^k.charCodeAt(i%k.length))).join('');if(!t)return'';if(t.startsWith('ENC:')){try{return '🔓 '+esc(x(decodeURIComponent(escape(atob(t.slice(4))))))}catch(e){return 'Cannot decrypt'}}return '🔒 <code>ENC:'+btoa(unescape(encodeURIComponent(x(t))))+'</code>'", "ph": "Message (or paste ENC:… to decrypt)", "ph2": "Secret key", "rows": 4, "k": "234-encrypted-text-messenger-demo"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();