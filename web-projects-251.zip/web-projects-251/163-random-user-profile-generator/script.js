const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://randomuser.me/api/?results=6');return '<div class=cards>'+d.results.map(u=>`<div class=card><img src=\"${esc(u.picture.large)}\" width=90><br><b>${esc(u.name.first+' '+u.name.last)}</b><br><small>${esc(u.email)}<br>${esc(u.location.country)}</small></div>`).join('')+'</div>'", "nq": 1, "btn": "Generate 6 users", "k": "163-random-user-profile-generator"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();