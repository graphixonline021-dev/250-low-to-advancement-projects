const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "anim", "m": "particles", "k": "185-particle-animation-background"};

const cv=$('#cv'),x=cv.getContext('2d'),W=cv.width=700,H=cv.height=400,m=CFG.m,rnd=Math.random;let F=[],T=0;
const P=[...Array(120)].map(()=>({x:rnd()*W,y:rnd()*H,vx:rnd()*2-1,vy:rnd()*2-1,r:rnd()*3+1,c:`hsl(${rnd()*360},80%,60%)`}));
const bl={x:100,y:50,vx:4,vy:0};
const A={
particles(){x.fillStyle='#0b1020';x.fillRect(0,0,W,H);P.forEach(p=>{p.x=(p.x+p.vx+W)%W;p.y=(p.y+p.vy+H)%H;x.fillStyle=p.c;x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()})},
confetti(){x.fillStyle='#fff';x.fillRect(0,0,W,H);P.forEach(p=>{p.y+=p.r+1;p.x+=Math.sin(T/20+p.r)*1.5;if(p.y>H)p.y=-10;x.fillStyle=p.c;x.fillRect(p.x,p.y,8,5)})},
fireworks(){x.fillStyle='rgba(0,0,20,.2)';x.fillRect(0,0,W,H);if(rnd()<.04){const c=`hsl(${rnd()*360},90%,60%)`,X=rnd()*W,Y=rnd()*H/2;for(let i=0;i<40;i++){const a=i/40*6.28,s=rnd()*3+1;F.push({x:X,y:Y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:60,c})}}F=F.filter(f=>f.l-->0);F.forEach(f=>{f.x+=f.vx;f.y+=f.vy;f.vy+=.03;x.fillStyle=f.c;x.fillRect(f.x,f.y,2,2)})},
bounce(){x.fillStyle='#123';x.fillRect(0,0,W,H);bl.vy+=.4;bl.x+=bl.vx;bl.y+=bl.vy;if(bl.y>H-20){bl.y=H-20;bl.vy*=-.9}if(bl.x<20||bl.x>W-20)bl.vx*=-1;x.fillStyle='#f84';x.beginPath();x.arc(bl.x,bl.y,20,0,7);x.fill()},
solar(){x.fillStyle='#000';x.fillRect(0,0,W,H);x.fillStyle='#fd0';x.beginPath();x.arc(350,200,26,0,7);x.fill();[['#aaa',50,5,4],['#e94',80,3.5,7],['#39f',115,3,8],['#c54',150,2.4,6],['#db8',185,1.3,14]].forEach(([c,r,s,z])=>{x.strokeStyle='#333';x.beginPath();x.arc(350,200,r,0,7);x.stroke();x.fillStyle=c;x.beginPath();x.arc(350+Math.cos(T*s/200)*r,200+Math.sin(T*s/200)*r,z,0,7);x.fill()})},
stars(){x.fillStyle='#0a0f2c';x.fillRect(0,0,W,H);P.forEach(p=>{x.globalAlpha=.4+.6*Math.abs(Math.sin(T/30+p.x));x.fillStyle='#fff';x.fillRect(p.x,p.y%H,p.r/1.5,p.r/1.5)});x.globalAlpha=1;x.fillStyle='#ffe9a8';x.beginPath();x.arc(580,80,36,0,7);x.fill();x.fillStyle='#0a0f2c';x.beginPath();x.arc(596,72,32,0,7);x.fill()},
rain(){x.fillStyle='#1b2433';x.fillRect(0,0,W,H);x.strokeStyle='#7ab';P.forEach(p=>{p.y+=8+p.r*2;if(p.y>H){p.y=-20;p.x=rnd()*W}x.beginPath();x.moveTo(p.x,p.y);x.lineTo(p.x-2,p.y+12);x.stroke()})},
snow(){x.fillStyle='#16283f';x.fillRect(0,0,W,H);x.fillStyle='#fff';P.forEach(p=>{p.y+=p.r*.5+.5;p.x+=Math.sin(T/40+p.r)*.5;if(p.y>H)p.y=-5;x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()})},
blob(){x.fillStyle='#101030';x.fillRect(0,0,W,H);x.filter='blur(30px)';[0,1,2,3].forEach(i=>{x.fillStyle=`hsl(${i*80+T/2},80%,55%)`;x.beginPath();x.arc(350+Math.cos(T/50+i*2)*200,200+Math.sin(T/40+i*3)*120,70,0,7);x.fill()});x.filter='none'},
wave(){x.fillStyle='#06283d';x.fillRect(0,0,W,H);[0,1,2].forEach(k=>{x.fillStyle=`hsla(${190+k*20},80%,${50-k*8}%,.6)`;x.beginPath();x.moveTo(0,H);for(let i=0;i<=W;i+=10)x.lineTo(i,200+k*30+Math.sin(i/60+T/20*(k+1))*30);x.lineTo(W,H);x.fill()})}};
(function loop(){T++;A[m]();requestAnimationFrame(loop)})();