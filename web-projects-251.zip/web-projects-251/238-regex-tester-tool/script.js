const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "if(!u)return esc(t);let r='',i=0,n=0;try{for(const m of t.matchAll(new RegExp(u,'g'))){if(!m[0])break;n++;r+=esc(t.slice(i,m.index))+'<mark>'+esc(m[0])+'</mark>';i=m.index+m[0].length}}catch(e){return 'Invalid pattern: '+esc(e.message)}return `<p>${n} match(es)</p><pre>${r+esc(t.slice(i))}</pre>`", "ph": "Test text…", "ph2": "Regex pattern, e.g. \\d+", "init": "Order 66 shipped on 2026-10-14", "k": "238-regex-tester-tool"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();