const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k": "057-monthly-calendar-app"};

let d=new Date();d.setDate(1);
function mv(n){d.setMonth(d.getMonth()+n);r()}
function r(){const y=d.getFullYear(),m=d.getMonth(),n=new Date(y,m+1,0).getDate(),s=d.getDay(),t=new Date();$('#out').innerHTML=`<h3>${d.toLocaleString('default',{month:'long'})} ${y}</h3><div class=cal>`+'SMTWTFS'.split('').map(x=>`<b>${x}</b>`).join('')+[...Array(s)].map(()=>'<i></i>').join('')+[...Array(n)].map((_,i)=>`<span class="${t.getFullYear()==y&&t.getMonth()==m&&t.getDate()==i+1?'today':''}">${i+1}</span>`).join('')+'</div>'}
r();