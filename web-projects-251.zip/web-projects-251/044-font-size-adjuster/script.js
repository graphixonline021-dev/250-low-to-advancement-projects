const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "fontsize", "k": "044-font-size-adjuster"};
let z=16;function fs(n){z=n?Math.max(10,Math.min(32,z+n*2)):16;document.documentElement.style.fontSize=z+'px'}