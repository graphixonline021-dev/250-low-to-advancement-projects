const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "scramble", "k": "082-word-scramble-game"};
const W=['planet','garden','window','coffee','rocket','guitar','island','pencil'];let w,sc=0;
function nw(){w=W[Math.floor(Math.random()*W.length)];$('#game').innerHTML=`<h2 class=mono>${[...w].sort(()=>Math.random()-.5).join(' ')}</h2><div class=row><input id=a><button onclick=ck()>Check</button></div>`}
function ck(){if($('#a').value.toLowerCase()==w){sc++;$('#out').textContent='Correct! Score '+sc;nw()}else $('#out').textContent='Try again'}nw();