const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "meme", "k": "180-meme-generator-studio"};

const cv=$('#cv'),x=cv.getContext('2d');let im=null;
function r(){x.fillStyle='#444';x.fillRect(0,0,500,500);if(im)x.drawImage(im,0,0,500,500);x.font='bold 40px Impact,sans-serif';x.textAlign='center';x.lineWidth=6;x.strokeStyle='#000';x.fillStyle='#fff';[[$('#t1').value,50],[$('#t2').value,480]].forEach(([s,y])=>{x.strokeText(s.toUpperCase(),250,y,480);x.fillText(s.toUpperCase(),250,y,480)})}
$('#f').onchange=e=>{im=new Image();im.onload=r;im.src=URL.createObjectURL(e.target.files[0])};document.querySelectorAll('input[type=text]').forEach(i=>i.oninput=r);r();
$('#sv').onclick=()=>{const a=document.createElement('a');a.href=cv.toDataURL();a.download='meme.png';a.click()};