const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "cursor", "k": "045-custom-cursor-effect"};
addEventListener('mousemove',e=>{$('#cu').style.transform=`translate(${e.clientX-15}px,${e.clientY-15}px)`})