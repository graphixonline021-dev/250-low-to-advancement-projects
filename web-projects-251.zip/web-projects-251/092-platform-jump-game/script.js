const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "platform", "k": "092-platform-jump-game"};
const x=$('#cv').getContext('2d');let y=250,v=0,O=[{x:400}],sc=0;const jp=()=>{if(y>=250)v=-9};addEventListener('keydown',e=>{if(e.code=='Space'){e.preventDefault();jp()}});$('#cv').onclick=jp;
const iv=setInterval(()=>{v+=.5;y=Math.min(250,y+v);if(y>=250)v=0;O.forEach(o=>o.x-=4);if(O[0].x<-20){O.shift();sc++}if(O[O.length-1].x<220)O.push({x:400+Math.random()*150});
x.fillStyle='#eef';x.fillRect(0,0,400,300);x.fillStyle='#363';x.fillRect(0,270,400,30);x.fillStyle='#36c';x.fillRect(40,y,20,20);x.fillStyle='#c33';O.forEach(o=>x.fillRect(o.x,250,20,20));$('#out').textContent='Score '+sc+' (Space / click to jump)';
if(O.some(o=>o.x<60&&o.x>20&&y>230)){clearInterval(iv);$('#out').textContent='Game over. Score '+sc}},16);