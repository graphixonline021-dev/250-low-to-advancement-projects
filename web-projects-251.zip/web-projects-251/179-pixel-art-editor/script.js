const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k2": "pixel", "k": "179-pixel-art-editor"};

let dn=0;$('#px').style.cssText='display:grid;grid-template-columns:repeat(16,24px);width:384px;border:1px solid #888';
$('#px').innerHTML=[...Array(256)].map(()=>'<div style="width:24px;height:24px;border:1px solid #8883;box-sizing:border-box"></div>').join('');
document.querySelectorAll('#px div').forEach(d=>{d.onpointerdown=e=>{d.releasePointerCapture&&d.releasePointerCapture(e.pointerId);dn=1;d.style.background=$('#c').value};d.onpointerenter=()=>dn&&(d.style.background=$('#c').value)});onpointerup=()=>dn=0;
$('#cl').onclick=()=>document.querySelectorAll('#px div').forEach(d=>d.style.background='');