const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "qr", "k": "230-qr-code-generator"};
$('#go').onclick=()=>$('#im').src='https://api.qrserver.com/v1/create-qr-code/?size=220x220&data='+encodeURIComponent($('#q').value);$('#go').click()