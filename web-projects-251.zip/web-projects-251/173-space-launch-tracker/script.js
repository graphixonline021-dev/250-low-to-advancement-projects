const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit=8');return d.results.map(l=>`<div class=card style=\"margin:.4rem 0\"><b>${esc(l.name)}</b><br><small>${new Date(l.net).toLocaleString()} · ${esc(l.status.name)}</small></div>`).join('')", "nq": 1, "btn": "Load launches", "k": "173-space-launch-tracker"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();