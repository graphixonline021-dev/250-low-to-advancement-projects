const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://hn.algolia.com/api/v1/search?tags=front_page&query='+encodeURIComponent(q));return d.hits.map(h=>`<div class=card style=\"margin:.4rem 0\"><a href=\"${esc(h.url||'#')}\" target=_blank>${esc(h.title)}</a><br><small>${h.points} points · ${esc(h.author)}</small></div>`).join('')", "ph": "Filter headlines (optional)", "btn": "Load", "k": "157-news-headlines-reader"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();