const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "if(!t.trim())return'';try{JSON.parse(t);return '✅ Valid JSON'}catch(e){return '❌ '+esc(e.message)}", "ph": "Paste JSON…", "btns": [["Format", "return JSON.stringify(JSON.parse(t),null,2)"], ["Minify", "return JSON.stringify(JSON.parse(t))"]], "init": "{\"name\":\"Alex\",\"skills\":[\"html\",\"css\"]}", "k": "239-json-formatter-and-validator"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();