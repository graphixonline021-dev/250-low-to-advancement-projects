const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"items": [["🎨", "Icon Pack", 12, "Design"], ["📐", "UI Kit", 29, "Design"], ["🎵", "Music Loops", 19, "Audio"], ["📚", "E-book Bundle", 15, "Books"], ["🧩", "Website Template", 39, "Web"]], "k": "146-digital-products-marketplace"};

const C=CFG,cats=['All',...new Set(C.items.map(i=>i[3]))];let cart=[],sel=new Set();
$('#form').innerHTML=`<input id=q placeholder=Search><select id=c>${cats.map(c=>`<option>${c}</option>`).join('')}</select><select id=s><option value=0>Sort</option><option value=1>Price ↑</option><option value=2>Price ↓</option></select>`;
function d(){let L=C.items.map((x,i)=>[...x,i]).filter(x=>x[1].toLowerCase().includes($('#q').value.toLowerCase())&&($('#c').value=='All'||x[3]==$('#c').value));const s=$('#s').value;if(s==1)L.sort((a,b)=>a[2]-b[2]);if(s==2)L.sort((a,b)=>b[2]-a[2]);
$('#grid').innerHTML=L.map(x=>`<div class=card><div class=big>${x[0]}</div><b>${esc(x[1])}</b><p>$${x[2].toFixed(2)} <small>${x[3]}</small></p><button onclick="add(${x[4]})">Add to cart</button>${C.cmp?`<label style="flex-direction:row"><input type=checkbox ${sel.has(x[4])?'checked':''} onchange="tg(${x[4]})"> compare</label>`:''}</div>`).join('');rc()}
function add(i){cart.push(i);rc()}
function tg(i){sel.has(i)?sel.delete(i):sel.add(i);rc()}
function rc(){const t=cart.reduce((a,i)=>a+C.items[i][2],0);$('#cart').innerHTML=`🛒 ${cart.length} item(s) — <b>$${t.toFixed(2)}</b> <button onclick="cart=[];rc()">Clear</button>`+(sel.size>1?'<table>'+[...sel].map(i=>`<tr><td>${C.items[i][0]} ${esc(C.items[i][1])}</td><td>$${C.items[i][2]}</td><td>${C.items[i][3]}</td></tr>`).join('')+'</table>':'')}
$('#form').oninput=d;d();