const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://openlibrary.org/search.json?limit=10&q='+encodeURIComponent(q));return d.docs.map(b=>`<div class=card style=\"margin:.4rem 0\"><b>${esc(b.title)}</b><br>${esc((b.author_name||[]).join(', '))} · ${b.first_publish_year||''}</div>`).join('')", "q": "javascript", "ph": "Book title or author", "k": "161-book-finder-application"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();