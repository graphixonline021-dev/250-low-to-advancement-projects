const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "simon", "k": "094-simon-says-memory-game"};
const col=['#e33','#3a3','#33e','#ec3'];let seq=[],pos=0,busy=1;$('#game').className='grid2';$('#game').innerHTML=col.map((c,i)=>`<button class=cell id=s${i} style="background:${c}" onclick=pk(${i})></button>`).join('');
const fl=i=>{$('#s'+i).style.opacity=.3;setTimeout(()=>$('#s'+i).style.opacity=1,300)};
function nx(){seq.push(Math.floor(Math.random()*4));pos=0;busy=1;seq.forEach((s,k)=>setTimeout(()=>fl(s),600*(k+1)));setTimeout(()=>{busy=0},600*seq.length+300);$('#out').textContent='Level '+seq.length}
function pk(i){if(busy)return;fl(i);if(i!=seq[pos]){$('#out').textContent='Wrong! Reached level '+seq.length;seq=[];busy=1;setTimeout(nx,1500);return}if(++pos==seq.length)setTimeout(nx,800)}nx();