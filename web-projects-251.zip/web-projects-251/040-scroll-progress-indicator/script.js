const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "scrollprog", "k": "040-scroll-progress-indicator"};
addEventListener('scroll',()=>{$('#sp').style.width=100*scrollY/(document.body.scrollHeight-innerHeight)+'%'})