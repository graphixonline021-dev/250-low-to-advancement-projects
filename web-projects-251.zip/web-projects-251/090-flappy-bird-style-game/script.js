const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "flappy", "k": "090-flappy-bird-style-game"};
const x=$('#cv').getContext('2d');let y=150,v=0,P=[{x:400,g:100}],sc=0;const fl=()=>v=-5;addEventListener('keydown',e=>{if(e.code=='Space'){e.preventDefault();fl()}});$('#cv').onclick=fl;
const iv=setInterval(()=>{v+=.3;y+=v;P.forEach(p=>p.x-=2);if(P[0].x<-40){P.shift();sc++}if(P[P.length-1].x<200)P.push({x:400,g:60+Math.random()*140});
x.fillStyle='#6cf';x.fillRect(0,0,400,300);x.fillStyle='#3a3';P.forEach(p=>{x.fillRect(p.x,0,40,p.g-45);x.fillRect(p.x,p.g+45,40,300)});x.fillStyle='#fd0';x.fillRect(30,y,20,20);$('#out').textContent='Score '+sc+' (Space / click to flap)';
if(y<0||y>300||P.some(p=>p.x<50&&p.x>-10&&(y<p.g-45||y>p.g+25))){clearInterval(iv);$('#out').textContent='Game over. Score '+sc}},16);