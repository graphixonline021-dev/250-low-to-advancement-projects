const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://api.tvmaze.com/search/shows?q='+encodeURIComponent(q));return '<div class=cards>'+d.map(({show:s})=>`<div class=card>${s.image?`<img src=\"${esc(s.image.medium)}\" width=120><br>`:''}<b>${esc(s.name)}</b><br><small>${esc((s.genres||[]).join(', '))} · ⭐ ${s.rating.average||'—'}</small></div>`).join('')+'</div>'", "q": "breaking", "ph": "TV show", "k": "159-tv-show-discovery-app"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();