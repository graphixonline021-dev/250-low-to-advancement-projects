const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "shooter", "k": "091-space-shooter-arcade"};
const x=$('#cv').getContext('2d'),cv=$('#cv');let px=200,B=[],En=[],sc=0,t=0;cv.onmousemove=e=>px=e.offsetX*400/cv.clientWidth;
const iv=setInterval(()=>{t++;if(t%10==0)B.push({x:px,y:280});if(t%40==0)En.push({x:Math.random()*380,y:0});B.forEach(b=>b.y-=6);En.forEach(e=>e.y+=1.5);B=B.filter(b=>b.y>0);
B.forEach(b=>En.forEach(e=>{if(!e.h&&Math.abs(b.x-e.x-10)<14&&Math.abs(b.y-e.y-10)<14){e.h=1;b.y=-9;sc++}}));En=En.filter(e=>!e.h);
x.fillStyle='#012';x.fillRect(0,0,400,300);x.fillStyle='#fff';x.fillRect(px-10,285,20,10);x.fillStyle='#ff0';B.forEach(b=>x.fillRect(b.x-1,b.y,3,8));x.fillStyle='#f44';En.forEach(e=>x.fillRect(e.x,e.y,20,20));$('#out').textContent='Score '+sc+' (move the mouse)';
if(En.some(e=>e.y>280)){clearInterval(iv);$('#out').textContent='Game over. Score '+sc}},16);