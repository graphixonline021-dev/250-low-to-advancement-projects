const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const r=await j('https://restcountries.com/v3.1/name/'+encodeURIComponent(q));return '<div class=cards>'+r.slice(0,6).map(c=>`<div class=card><span class=big>${c.flag}</span> <b>${esc(c.name.common)}</b><br>Capital: ${esc((c.capital||[])[0]||'—')}<br>Population: ${c.population.toLocaleString()}<br>Region: ${c.region}</div>`).join('')+'</div>'", "q": "pakistan", "ph": "Country name", "k": "153-country-explorer-app"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();