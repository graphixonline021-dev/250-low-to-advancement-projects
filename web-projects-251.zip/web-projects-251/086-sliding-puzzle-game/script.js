const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "slide", "k": "086-sliding-puzzle-game"};
let a=[1,2,3,4,5,6,7,8,0];for(let k=0;k<200;k++){const z=a.indexOf(0),n=[z-3,z+3,z%3?z-1:-1,z%3<2?z+1:-1].filter(i=>i>=0&&i<9),m=n[Math.floor(Math.random()*n.length)];[a[z],a[m]]=[a[m],a[z]]}
const G=$('#game');G.className='grid3';function d(){G.innerHTML=a.map((v,i)=>`<button class=cell onclick=mv(${i})>${v||''}</button>`).join('');$('#out').textContent=a.join()=='1,2,3,4,5,6,7,8,0'?'Solved! 🎉':''}
function mv(i){const z=a.indexOf(0);if([i-3,i+3,i%3?i-1:-9,i%3<2?i+1:-9].includes(z)){[a[z],a[i]]=[a[i],a[z]];d()}}d();