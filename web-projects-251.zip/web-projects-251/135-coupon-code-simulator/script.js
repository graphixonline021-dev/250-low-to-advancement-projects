const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"f": [["s", "Subtotal", 100], ["c", "Coupon code", "SAVE10", "text"]], "js": "const c={SAVE10:.1,SAVE20:.2,HALF:.5}[v.c.toUpperCase()];return c?`Code applied! Total: <div class=big>$${(v.s*(1-c)).toFixed(2)}</div>`:`No valid code (try SAVE10, SAVE20, HALF). Total $${v.s.toFixed(2)}`", "k": "135-coupon-code-simulator"};

$('#form').innerHTML=CFG.f.map(([i,l,d,o])=>`<label>${l}${Array.isArray(o)?`<select id=${i}>${o.map(x=>`<option>${x}</option>`).join('')}</select>`:`<input id=${i} type=${o||'number'} value="${d}">`}</label>`).join('');
const run=()=>{const v={};CFG.f.forEach(([i,,,o])=>{const e=$('#'+i);v[i]=o?e.value:+e.value});try{$('#out').innerHTML=new Function('v',CFG.js)(v)}catch(e){$('#out').textContent='Check your inputs'}};
$('#form').oninput=run;run();