const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "let s=0;if(t.length>=8)s++;if(t.length>=12)s++;if(/[a-z]/.test(t)&&/[A-Z]/.test(t))s++;if(/\\d/.test(t))s++;if(/[^\\w]/.test(t))s++;const L=['Very weak','Weak','Fair','Good','Strong','Excellent'];return `<div class=bar><i style=\\\"width:${s*20}%;background:hsl(${s*24},70%,45%)\\\"></i></div><p>${t?L[s]:'Type a password'}</p>`", "ph": "Type a password…", "rows": 1, "k": "105-password-strength-checker"};

const run=()=>{try{const r=new Function('t','u',CFG.js)($('#t').value,$('#t2')?$('#t2').value:'');CFG.frame?$('#out').srcdoc=r:$('#out').innerHTML=r}catch(e){$('#out').textContent=e.message}};
document.querySelectorAll('textarea').forEach(e=>e.oninput=run);
(CFG.btns||[]).forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{try{$('#t').value=new Function('t',f)($('#t').value)}catch(e){$('#out').textContent=e.message;return}run()};$('#btns').append(b)});
if(CFG.init)$('#t').value=CFG.init;run();