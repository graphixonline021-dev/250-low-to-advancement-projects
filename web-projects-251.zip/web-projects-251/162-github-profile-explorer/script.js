const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const u=await j('https://api.github.com/users/'+encodeURIComponent(q));return `<div class=card><img src=\"${esc(u.avatar_url)}\" width=90><h3>${esc(u.name||u.login)}</h3>${esc(u.bio||'')}<p>Repos ${u.public_repos} · Followers ${u.followers} · Following ${u.following}</p><a href=\"${esc(u.html_url)}\" target=_blank>Open profile</a></div>`", "q": "torvalds", "ph": "GitHub username", "k": "162-github-profile-explorer"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();