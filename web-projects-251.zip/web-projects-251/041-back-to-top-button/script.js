const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "backtop", "k": "041-back-to-top-button"};
addEventListener('scroll',()=>$('#bt').hidden=scrollY<200);$('#bt').onclick=()=>scrollTo({top:0,behavior:'smooth'})