const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY');return `<h3>${esc(d.title)}</h3>${d.media_type=='image'?`<img src=\"${esc(d.url)}\">`:`<a href=\"${esc(d.url)}\" target=_blank>Open media</a>`}<p>${esc(d.explanation)}</p>`", "nq": 1, "btn": "Today's picture", "k": "174-astronomy-picture-viewer"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();