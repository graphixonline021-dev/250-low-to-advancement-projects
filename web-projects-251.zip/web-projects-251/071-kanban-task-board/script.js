const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"k": "071-kanban-task-board"};

const cols=['To Do','Doing','Done'],K='kb_'+CFG.k;let B=JSON.parse(localStorage.getItem(K)||'[]');
function sv(){localStorage.setItem(K,JSON.stringify(B));d()}
function d(){$('#board').innerHTML=cols.map((c,ci)=>`<div class=card><h3>${c}</h3>`+B.map((x,i)=>x.c==ci?`<div class=note>${ci?`<button onclick="B[${i}].c--;sv()">◀</button>`:''}<span style="flex:1">${esc(x.t)}</span>${ci<2?`<button onclick="B[${i}].c++;sv()">▶</button>`:''}<button onclick="B.splice(${i},1);sv()">✕</button></div>`:'').join('')+'</div>').join('')}
$('#add').onclick=()=>{if($('#nt').value){B.push({t:$('#nt').value,c:0});$('#nt').value='';sv()}};d();