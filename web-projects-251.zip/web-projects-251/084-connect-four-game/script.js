const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "c4", "k": "084-connect-four-game"};
const R=6,C=7;let b=[...Array(R)].map(()=>Array(C).fill(0)),t=1,over=0;const G=$('#game');G.className='grid7';
function d(){G.innerHTML=b.flatMap((r,i)=>r.map((v,j)=>`<button class=cell onclick=dr(${j}) style="background:${['','#e33','#ec3'][v]||''}"></button>`)).join('')}
function dr(c){if(over)return;for(let r=R-1;r>=0;r--)if(!b[r][c]){b[r][c]=t;if(win(r,c)){over=1;$('#out').textContent='Player '+t+' wins! 🎉'}t=3-t;d();return}}
function win(r,c){return[[0,1],[1,0],[1,1],[1,-1]].some(([a,e])=>{let n=1;for(const s of[1,-1]){let i=r+a*s,j=c+e*s;while(b[i]&&b[i][j]==t){n++;i+=a*s;j+=e*s}}return n>=4})}d();