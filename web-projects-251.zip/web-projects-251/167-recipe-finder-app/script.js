const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"js": "const d=await j('https://www.themealdb.com/api/json/v1/1/search.php?s='+encodeURIComponent(q));return (d.meals||[]).map(m=>`<div class=card style=\"margin:.4rem 0\"><img src=\"${esc(m.strMealThumb)}\" width=120><h3>${esc(m.strMeal)}</h3><small>${esc(m.strCategory)} · ${esc(m.strArea)}</small><p>${esc(m.strInstructions.slice(0,200))}…</p></div>`).join('')||'No recipes found'", "q": "chicken", "ph": "Dish name", "k": "167-recipe-finder-app"};

const AF=Object.getPrototypeOf(async function(){}).constructor,j=u=>fetch(u).then(r=>{if(!r.ok)throw 0;return r.json()});
const fn=new AF('q','esc','j',CFG.js);$('#q').value=CFG.q||'';
async function go(){$('#out').textContent='Loading…';try{$('#out').innerHTML=await fn($('#q').value.trim(),esc,j)||'No results'}catch(e){$('#out').textContent='Could not load data — this project needs an internet connection (and the free public API may be rate-limited).'}}
$('#go').onclick=go;$('#q').onkeydown=e=>e.key=='Enter'&&go();go();