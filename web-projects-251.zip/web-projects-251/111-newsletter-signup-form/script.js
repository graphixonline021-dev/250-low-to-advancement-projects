const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"f": [["email", "Email", "email", "email"]], "ok": "Subscribed!", "k": "111-newsletter-signup-form"};

const C=CFG,F=C.f,sz=C.steps||F.length,K='frm_'+C.k;let st=0,V=C.save?JSON.parse(localStorage.getItem(K)||'{}'):{};
const ER={req:v=>v?'':'Required',email:v=>/^[^@\s]+@[^@\s]+\.\w{2,}$/.test(v)?'':'Enter a valid email',phone:v=>/^\+?[\d\s-]{7,15}$/.test(v)?'':'Enter a valid phone number',min8:v=>v.length>=8?'':'At least 8 characters',card:v=>/^\d{13,19}$/.test(v.replace(/\s/g,''))?'':'Invalid card number'};
const part=()=>F.slice(st*sz,(st+1)*sz),last=()=>(st+1)*sz>=F.length,grab=()=>part().forEach(([i])=>V[i]=$('#'+i).value);
function draw(){$('#form').innerHTML=(C.steps?`<p>Step ${st+1} of ${Math.ceil(F.length/sz)}</p>`:'')+part().map(([i,l,t])=>`<label>${l}${t=='area'?`<textarea id=${i}>${esc(V[i])}</textarea>`:Array.isArray(t)?`<select id=${i}>${t.map(o=>`<option ${V[i]==o?'selected':''}>${o}</option>`).join('')}</select>`:`<input id=${i} type=${t} value="${esc(V[i])}">`}<small class=err id=e_${i}></small></label>`).join('')+`<div class=row style="margin-top:.8rem">${st?'<button id=bk type=button>Back</button>':''}<button id=nx type=button>${last()?'Submit':'Next'}</button></div>`;
const upd=()=>part().forEach(([i,,,,c])=>{if(c)$('#'+i).parentElement.style.display=$('#'+c[0]).value==c[1]?'':'none'});
$('#form').oninput=()=>{grab();if(C.save)localStorage.setItem(K,JSON.stringify(V));upd()};upd();
if($('#bk'))$('#bk').onclick=()=>{grab();st--;draw()};
$('#nx').onclick=()=>{grab();let ok=1;part().forEach(([i,,,r,c])=>{const h=c&&$('#'+c[0]).value!=c[1],m=!h&&r?ER[r]($('#'+i).value):'';$('#e_'+i).textContent=m;if(m)ok=0});if(!ok)return;if(last()){$('#form').innerHTML='';$('#out').innerHTML='✅ '+(C.ok||'Submitted successfully!')+'<pre>'+esc(JSON.stringify(Object.fromEntries(Object.entries(V).filter(([k])=>!/pass|card|cvv/i.test(k))),null,2))+'</pre>'}else{st++;draw()}}}
draw();