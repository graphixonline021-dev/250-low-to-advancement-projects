const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"c": "toast", "k": "036-toast-notification-system"};
function ts(m,c){const d=document.createElement('div');d.className='toast';d.style.background=c;d.textContent=m;$('#tt').append(d);setTimeout(()=>d.remove(),3000)}