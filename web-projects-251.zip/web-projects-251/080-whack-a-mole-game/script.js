const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const CFG={"g": "whack", "k": "080-whack-a-mole-game"};
let sc=0,t=30,cur=-1;const G=$('#game');G.className='grid3';G.innerHTML=[...Array(9)].map((_,i)=>`<button class=cell id=h${i} onclick=hit(${i})></button>`).join('');
function hit(i){if(i==cur){sc++;$('#h'+i).textContent='';cur=-1}}
const iv=setInterval(()=>{if(cur>=0)$('#h'+cur).textContent='';cur=Math.floor(Math.random()*9);$('#h'+cur).textContent='🐹'},700);
const tm=setInterval(()=>{t--;$('#out').textContent=`Score ${sc} · Time ${t}s`;if(t<=0){clearInterval(iv);clearInterval(tm);$('#out').textContent='Game over! Score '+sc}},1000);